#!/usr/bin/env bash
# Run linting, formatting checks and the full test suite.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$here"
echo "== ruff check =="; python -m ruff check shared backend
echo "== ruff format --check =="; python -m ruff format --check shared backend
echo "== pytest =="; cd backend && PYTHONPATH=".:$here/shared" python -m pytest -q
