"""Binds the shared E2EE core to encrypted local storage and the backend."""
from __future__ import annotations

from typing import Optional

from msj_crypto import SessionManager, X3DHState, bundle_from_bundle_response, bundle_to_wire
from msj_crypto.constants import APP_INFO
from x3dh import HashFunction, IdentityKeyFormat

from .storage import FileSecureStore


class MessengerCrypto:
    """Owns a user's X3DH state and Double Ratchet sessions, persisted encrypted."""

    def __init__(self, store: FileSecureStore, own_username: str, pre_key_batch: int = 100) -> None:
        self.store = store
        self.own_username = own_username
        self.pre_key_batch = pre_key_batch
        self.manager = SessionManager(own_username)

    # ---- lifecycle --------------------------------------------------------

    def load_or_create(self) -> bool:
        """Load existing state, or create a fresh identity.

        Returns True if a new identity was created (so the caller should publish
        the bundle to the backend).
        """
        data = self.store.load()
        if data is None:
            self.manager = SessionManager(self.own_username, state=X3DHState.new(num_pre_keys=self.pre_key_batch))
            self.persist()
            return True

        state, _needs_publish = X3DHState.from_json(
            data["x3dh"], IdentityKeyFormat.CURVE_25519, HashFunction.SHA_256, APP_INFO
        )
        self.manager = SessionManager(self.own_username, state=state)
        self.manager.load_sessions(data.get("sessions", {}))
        return False

    def persist(self) -> None:
        """Write identity + session state to encrypted storage."""
        self.store.save({"x3dh": self.manager.state.json, "sessions": self.manager.export_sessions()})

    # ---- key distribution -------------------------------------------------

    def bundle_wire(self) -> dict:
        return bundle_to_wire(self.manager.bundle)

    def pre_key_count(self) -> int:
        return self.manager.state.get_num_visible_pre_keys()

    def replenish_pre_keys(self) -> None:
        self.manager.state.generate_pre_keys(self.pre_key_batch)

    @staticmethod
    def bundle_from_response(resp: dict):
        return bundle_from_bundle_response(resp)

    # ---- messaging --------------------------------------------------------

    async def encrypt(self, peer_username: str, plaintext: bytes, peer_bundle_response: Optional[dict] = None):
        """Encrypt a message. Provide the peer's bundle response when starting a
        new conversation; afterwards it is optional."""
        peer_bundle = None
        if not self.manager.has_session(peer_username):
            if peer_bundle_response is None:
                raise ValueError("peer bundle required to start a new session")
            peer_bundle = bundle_from_bundle_response(peer_bundle_response)
        envelope = await self.manager.encrypt(peer_username, plaintext, peer_bundle=peer_bundle)
        self.persist()
        return envelope

    async def decrypt(self, peer_username: str, envelope):
        plaintext = await self.manager.decrypt(peer_username, envelope)
        self.persist()
        return plaintext

    def safety_number(self, peer_username: str, peer_identity_key: bytes) -> str:
        return self.manager.safety_number(peer_username, peer_identity_key)
