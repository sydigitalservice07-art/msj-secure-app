"""Client configuration."""
from __future__ import annotations

import os
from dataclasses import dataclass, field

APP_NAME = "MSJ Secure"


@dataclass
class ClientConfig:
    # Backend endpoints. Use https:// and wss:// in production.
    base_url: str = field(default_factory=lambda: os.environ.get("MSJ_BASE_URL", "https://localhost:8443"))
    ws_path: str = "/api/v1/ws"
    request_timeout: float = 20.0
    # Where encrypted local state lives.
    data_dir: str = field(default_factory=lambda: os.environ.get("MSJ_DATA_DIR", "./msj_client_data"))
    # How many one-time pre keys to publish / keep topped up.
    pre_key_batch: int = 100
    pre_key_low_watermark: int = 20

    @property
    def ws_url(self) -> str:
        base = self.base_url
        if base.startswith("https://"):
            base = "wss://" + base[len("https://") :]
        elif base.startswith("http://"):
            base = "ws://" + base[len("http://") :]
        return base.rstrip("/") + self.ws_path
