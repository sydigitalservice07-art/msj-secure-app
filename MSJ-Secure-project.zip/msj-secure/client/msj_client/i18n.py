"""Minimal localisation scaffold.

English is complete; Gujarati is stubbed so the structure is ready for real
translations without touching UI code. Add a locale by filling its dictionary
and calling :func:`set_locale`.
"""
from __future__ import annotations

_STRINGS: dict[str, dict[str, str]] = {
    "en": {
        "app_name": "MSJ Secure",
        "welcome_tagline": "Private, end-to-end encrypted messaging",
        "register": "Create account",
        "login": "Sign in",
        "username": "Username",
        "password": "Password",
        "chats": "Chats",
        "search": "Search users",
        "send": "Send",
        "type_message": "Type a message",
        "encryption_on": "Messages are end-to-end encrypted",
        "verify": "Verify safety number",
        "devices": "Active devices",
        "security": "Privacy & security",
        "settings": "Settings",
        "logout": "Sign out",
    },
    # Placeholder structure for Gujarati; fill with real translations.
    "gu": {
        "app_name": "MSJ Secure",
        "welcome_tagline": "ખાનગી, એન્ડ-ટુ-એન્ડ એન્ક્રિપ્ટેડ મેસેજિંગ",
        "register": "ખાતું બનાવો",
        "login": "સાઇન ઇન",
        "username": "વપરાશકર્તાનામ",
        "password": "પાસવર્ડ",
        "chats": "ચેટ",
        "search": "વપરાશકર્તા શોધો",
        "send": "મોકલો",
        "type_message": "સંદેશ લખો",
        "encryption_on": "સંદેશા એન્ડ-ટુ-એન્ડ એન્ક્રિપ્ટેડ છે",
        "verify": "સેફ્ટી નંબર ચકાસો",
        "devices": "સક્રિય ઉપકરણો",
        "security": "ગોપનીયતા અને સુરક્ષા",
        "settings": "સેટિંગ્સ",
        "logout": "સાઇન આઉટ",
    },
}

_locale = "en"


def set_locale(code: str) -> None:
    global _locale
    if code in _STRINGS:
        _locale = code


def get_locale() -> str:
    return _locale


def tr(key: str) -> str:
    return _STRINGS.get(_locale, {}).get(key) or _STRINGS["en"].get(key, key)
