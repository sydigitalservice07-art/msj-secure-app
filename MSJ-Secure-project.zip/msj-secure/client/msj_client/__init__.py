"""MSJ Secure Android client (Python + Kivy).

The package is split so that everything except the Kivy UI can be imported and
tested on a desktop without a display or the Android toolchain:

* ``config``         — client configuration
* ``storage``        — encrypted-at-rest local state (identity + ratchet)
* ``api``            — REST + WebSocket transport to the backend
* ``crypto_adapter`` — binds the shared E2EE core to storage and the API
"""
