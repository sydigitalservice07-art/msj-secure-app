"""MSJ Secure — Kivy Android client entrypoint.

The UI is deliberately thin: all networking and cryptography live in the
``msj_client`` package, which is unit-tested on desktop. This module only wires
Kivy screens to that logic.

Run on a desktop for a quick look (``python main.py``) or package for Android
with Buildozer (see ``buildozer.spec`` and docs/APK_BUILD.md).
"""
from __future__ import annotations

import asyncio
import os
import threading
import uuid

from kivy.app import App
from kivy.clock import Clock
from kivy.lang import Builder
from kivy.properties import BooleanProperty, ListProperty, StringProperty
from kivy.uix.screenmanager import Screen, ScreenManager

from msj_client import i18n
from msj_client.api import ApiClient, ApiError, RealtimeClient
from msj_client.config import APP_NAME, ClientConfig
from msj_client.crypto_adapter import MessengerCrypto
from msj_client.storage import FileSecureStore

from msj_crypto import Envelope


class AsyncBridge:
    """Runs an asyncio event loop on a background thread.

    Kivy is not asyncio-native; this lets the UI call coroutines and receive
    results back on the Kivy main thread via ``Clock.schedule_once``.
    """

    def __init__(self) -> None:
        self.loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run, name="msj-asyncio", daemon=True)
        self._thread.start()

    def _run(self) -> None:
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def submit(self, coro, on_success=None, on_error=None):
        future = asyncio.run_coroutine_threadsafe(coro, self.loop)

        def _done(fut):
            try:
                result = fut.result()
            except Exception as exc:  # noqa: BLE001 - surfaced to the UI
                if on_error:
                    Clock.schedule_once(lambda _dt: on_error(exc))
            else:
                if on_success:
                    Clock.schedule_once(lambda _dt: on_success(result))

        future.add_done_callback(_done)
        return future

    def stop(self) -> None:
        self.loop.call_soon_threadsafe(self.loop.stop)


class BaseScreen(Screen):
    status = StringProperty("")
    busy = BooleanProperty(False)


class WelcomeScreen(BaseScreen):
    pass


class RegisterScreen(BaseScreen):
    def do_register(self, username: str, password: str) -> None:
        app = App.get_running_app()
        if not username or not password:
            self.status = "Enter a username and password."
            return
        self.busy = True
        self.status = "Creating account…"
        app.bridge.submit(
            app.do_register(username.strip(), password),
            on_success=lambda _r: self._ok(),
            on_error=self._err,
        )

    def _ok(self) -> None:
        self.busy = False
        self.status = ""
        self.manager.current = "chats"

    def _err(self, exc: Exception) -> None:
        self.busy = False
        self.status = str(exc)


class LoginScreen(BaseScreen):
    def do_login(self, username: str, password: str) -> None:
        app = App.get_running_app()
        if not username or not password:
            self.status = "Enter your username and password."
            return
        self.busy = True
        self.status = "Signing in…"
        app.bridge.submit(
            app.do_login(username.strip(), password),
            on_success=lambda _r: self._ok(),
            on_error=self._err,
        )

    def _ok(self) -> None:
        self.busy = False
        self.status = ""
        self.manager.current = "chats"

    def _err(self, exc: Exception) -> None:
        self.busy = False
        self.status = str(exc)


class ChatListScreen(BaseScreen):
    conversations = ListProperty([])

    def on_pre_enter(self, *_args) -> None:
        self.conversations = App.get_running_app().conversations

    def open_conversation(self, peer: str) -> None:
        App.get_running_app().open_conversation(peer)


class SearchScreen(BaseScreen):
    results = ListProperty([])

    def do_search(self, query: str) -> None:
        app = App.get_running_app()
        if not query.strip():
            return
        app.bridge.submit(app.do_search(query.strip()), on_success=self._set_results, on_error=self._err)

    def _set_results(self, results) -> None:
        self.results = results

    def _err(self, exc: Exception) -> None:
        self.status = str(exc)

    def start_chat(self, username: str) -> None:
        App.get_running_app().open_conversation(username)


class ConversationScreen(BaseScreen):
    peer = StringProperty("")
    messages = ListProperty([])  # list of {"who": "me"/"them", "text": str, "state": str}

    def load(self, peer: str) -> None:
        self.peer = peer
        self.messages = []
        app = App.get_running_app()
        app.bridge.submit(app.load_history(peer), on_success=self._on_history, on_error=self._err)

    def _on_history(self, messages) -> None:
        self.messages = messages
        app = App.get_running_app()
        for m in messages:
            if m.get("id"):
                app.bridge.submit(app.mark_read(m["id"]))

    def send(self, text: str) -> None:
        if not text.strip():
            return
        app = App.get_running_app()
        self.messages = self.messages + [{"who": "me", "text": text, "state": "sending"}]
        app.bridge.submit(app.send_text(self.peer, text.strip()), on_success=self._sent, on_error=self._err)

    def _sent(self, _r) -> None:
        self.messages = [dict(m, state="sent") if m["state"] == "sending" else m for m in self.messages]

    def _err(self, exc: Exception) -> None:
        self.status = str(exc)

    def verify(self) -> None:
        App.get_running_app().show_safety_number(self.peer)


class ProfileScreen(BaseScreen):
    username = StringProperty("")
    user_id = StringProperty("")


class DevicesScreen(BaseScreen):
    devices = ListProperty([])

    def on_pre_enter(self, *_args) -> None:
        app = App.get_running_app()
        app.bridge.submit(app.load_devices(), on_success=self._set, on_error=lambda e: setattr(self, "status", str(e)))

    def _set(self, devices) -> None:
        self.devices = devices


class SecurityScreen(BaseScreen):
    safety_number = StringProperty("")
    note = StringProperty(
        "Messages are end-to-end encrypted. The server relays ciphertext only and "
        "cannot read your messages. Metadata (such as who talks to whom and when) "
        "is not hidden."
    )


class SettingsScreen(BaseScreen):
    pass


class MSJApp(App):
    title = APP_NAME

    def build(self):
        self.bridge = AsyncBridge()
        self.config = ClientConfig()
        self.api: ApiClient | None = None
        self.crypto: MessengerCrypto | None = None
        self.realtime: RealtimeClient | None = None
        self.username = ""
        self.conversations = []
        self._realtime_task = None
        self._peer_bundles: dict[str, dict] = {}
        i18n.set_locale("en")
        return Builder.load_file(os.path.join(os.path.dirname(__file__), "ui", "msj.kv"))

    # ---- account ----------------------------------------------------------

    async def do_register(self, username: str, password: str):
        self.api = ApiClient(self.config)
        await self.api.register(username, password, device_name="android")
        self._init_crypto(username, password, fresh=True)
        await self.api.publish_bundle(self.crypto.bundle_wire())
        await self._start_realtime()
        return True

    async def do_login(self, username: str, password: str):
        self.api = ApiClient(self.config)
        await self.api.login(username, password, device_name="android")
        self._init_crypto(username, password, fresh=False)
        if not self.crypto.manager.has_session("__never__") and self.crypto.pre_key_count() <= self.config.pre_key_low_watermark:
            self.crypto.replenish_pre_keys()
        await self.api.publish_bundle(self.crypto.bundle_wire())
        await self._start_realtime()
        return True

    def _init_crypto(self, username: str, password: str, fresh: bool) -> None:
        self.username = username
        path = os.path.join(self.config.data_dir, f"{username}.json")
        store = FileSecureStore(path, password)
        self.crypto = MessengerCrypto(store, username, pre_key_batch=self.config.pre_key_batch)
        created = self.crypto.load_or_create()
        if created and not fresh:
            # A returning user with no local state must re-publish keys.
            pass

    # ---- realtime ---------------------------------------------------------

    async def _start_realtime(self) -> None:
        self.realtime = RealtimeClient(self.config, self.api)
        self._realtime_task = asyncio.create_task(self.realtime.run(self._on_realtime_event))

    async def _on_realtime_event(self, event: dict) -> None:
        etype = event.get("type")
        if etype == "message":
            await self._receive(event)
        elif etype == "receipt":
            self._apply_receipt(event)
        elif etype == "ack":
            pass

    async def _receive(self, event: dict) -> None:
        peer = event.get("sender")
        envelope = Envelope.from_dict(event["envelope"])
        try:
            plaintext = await self.crypto.decrypt(peer, envelope)
        except Exception:
            return
        Clock.schedule_once(lambda _dt: self._append_incoming(peer, plaintext.decode("utf-8", "replace")))
        if event.get("id"):
            await self.api.send_receipt(event["id"], "delivered")

    def _append_incoming(self, peer: str, text: str) -> None:
        if peer not in self.conversations:
            self.conversations = self.conversations + [peer]
        sm = self.root
        if sm and sm.current == "conversation" and sm.get_screen("conversation").peer == peer:
            conv = sm.get_screen("conversation")
            conv.messages = conv.messages + [{"who": "them", "text": text, "state": ""}]

    def _apply_receipt(self, event: dict) -> None:
        pass  # hook for per-message state once message ids are tracked in the UI

    # ---- actions ----------------------------------------------------------

    def open_conversation(self, peer: str) -> None:
        self.root.get_screen("conversation").load(peer)
        self.root.current = "conversation"

    async def do_search(self, query: str):
        data = await self.api.search_users(query)
        return [u["username"] for u in data["results"]]

    async def load_history(self, peer: str):
        page = await self.api.history(peer)
        out = []
        for m in reversed(page["messages"]):
            who = "me" if m["sender"] == self.username else "them"
            try:
                text = (await self.crypto.decrypt(peer, Envelope.from_dict(m["envelope"]))).decode("utf-8", "replace")
            except Exception:
                text = "[cannot decrypt]"
            out.append({"who": who, "text": text, "state": "read" if m.get("read_at") else "sent", "id": m["id"]})
        return out

    async def send_text(self, peer: str, text: str):
        if peer not in self._peer_bundles:
            self._peer_bundles[peer] = await self.api.fetch_bundle(peer)
        envelope = await self.crypto.encrypt(peer, text.encode("utf-8"), peer_bundle_response=self._peer_bundles[peer])
        return await self.api.send_message(str(uuid.uuid4()), peer, envelope.to_dict())

    async def mark_read(self, message_id: str):
        await self.api.send_receipt(message_id, "read")

    async def load_devices(self):
        return await self.api.list_devices()

    def show_safety_number(self, peer: str) -> None:
        screen = self.root.get_screen("security")
        screen.safety_number = "Fetch a message from this contact first to derive the safety number."
        self.root.current = "security"

    async def do_logout(self):
        try:
            if self.realtime:
                await self.realtime.stop()
            if self.api:
                await self.api.logout()
                await self.api.aclose()
        finally:
            self.crypto = None
            self.api = None
        return True

    def logout(self) -> None:
        self.bridge.submit(self.do_logout(), on_success=lambda _r: setattr(self.root, "current", "welcome"))

    def on_stop(self) -> None:
        if self.bridge:
            self.bridge.stop()


if __name__ == "__main__":
    MSJApp().run()
