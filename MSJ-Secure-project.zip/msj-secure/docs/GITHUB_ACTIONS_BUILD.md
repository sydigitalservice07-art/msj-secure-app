# Building the APK with GitHub Actions (no computer needed)

GitHub's servers build the APK for you. You can do all of this from a phone.

## 1. Put the project on GitHub

1. Create a free account at https://github.com (if you don't have one).
2. Create a new repository (the green **New** button). Give it a name, e.g.
   `msj-secure`. A **public** repo gets unlimited free build minutes.
3. On the new repo page, click **Add file → Upload files**, select
   `MSJ-Secure-project.zip`, and click **Commit changes**.

## 2. Add the build workflow (must be at the repo root)

The workflow file has to live at `.github/workflows/android.yml` in the
repository root, so create it there:

1. Click **Add file → Create new file**.
2. In the filename box type exactly: `.github/workflows/android.yml`
3. Paste the contents of `.github/workflows/android.yml` from this project.
4. Click **Commit changes**.

## 3. Run the build

1. Open the **Actions** tab. A run named "Build Android APK" starts (or click
   **Run workflow**).
2. Wait. The first run downloads the Android SDK/NDK, so it can take
   **30–60 minutes**.
3. When it finishes, open the run and download the **msj-secure-debug-apk**
   artifact — inside is `msjsecure-1.0.0-debug.apk`.
4. Install that APK on your phone (allow "install from unknown sources").

## Notes and known caveats

- The workflow unzips `MSJ-Secure-project.zip` automatically, so you only need
  to upload that one file plus the workflow.
- If you prefer, upload the project files directly (so `client/`, `shared/`,
  `backend/` are at the repo root) and skip the zip — the workflow handles both.
- **`xeddsa` recipe:** `xeddsa` is a cffi C extension without a ready
  python-for-android recipe. If the build fails on it, a small custom recipe is
  needed (see `docs/APK_BUILD.md`). This is the most likely first-run failure;
  read the log and we can fix it together.
- Build minutes: public repositories are free; private repositories use your
  monthly free minutes (the first cached run is the slow one).
