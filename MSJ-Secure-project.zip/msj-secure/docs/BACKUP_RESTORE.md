# Database backup, restore and retention

## What is backed up

The database contains **only ciphertext and public key material**:

- account records (username, Argon2id password hash),
- public key bundles and public one-time pre-keys,
- **ciphertext** message envelopes and delivery metadata.

Backups therefore contain **no plaintext messages and no private keys**. They
still contain metadata (who messaged whom, when) and must be protected as
sensitive and encrypted at rest.

## PostgreSQL backup

```bash
# Custom-format dump (recommended)
pg_dump -Fc -U msj -h localhost msj > msj_$(date +%F).dump

# Plain SQL
pg_dump -U msj -h localhost msj | gzip > msj_$(date +%F).sql.gz
```

## Restore

```bash
createdb -U msj msj_restored
pg_restore -U msj -d msj_restored --clean --if-exists msj_$(date +%F).dump
```

Then point `MSJ_DATABASE_URL` at the restored database and run
`alembic upgrade head` to ensure the schema is current.

## SQLite backup (development only)

```bash
sqlite3 msj_dev.db ".backup 'msj_dev_backup.db'"
```

## Migrations

```bash
cd backend
PYTHONPATH=.:../shared alembic upgrade head     # apply
PYTHONPATH=.:../shared alembic downgrade -1     # roll back one revision
```

The initial schema lives in `backend/migrations/versions/`. In development and
tests the app can also create tables directly via `init_models()`; production
should rely on Alembic.

## Retention

Messages carry an `expires_at` set to `now + MSJ_MESSAGE_RETENTION_DAYS`. Add a
scheduled purge (e.g. cron or a systemd timer):

```sql
DELETE FROM messages WHERE expires_at IS NOT NULL AND expires_at < now();
```

Account deletion (`POST /api/v1/auth/delete-account`) cascades to devices,
tokens, bundles, pre-keys and messages.
