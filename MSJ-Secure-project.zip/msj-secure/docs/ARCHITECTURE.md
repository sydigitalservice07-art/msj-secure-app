# Architecture

## Overview

```
 Android client (Kivy)                     Backend (FastAPI)
 ┌───────────────────────┐                 ┌──────────────────────────┐
 │ UI (ui/msj.kv)        │                 │ REST routers             │
 │ main.py (screens)     │  HTTPS / WSS    │  auth keys users         │
 │ msj_client/api.py     │ ───────────────▶│  messages devices        │
 │ msj_client/crypto_... │                 │ WebSocket relay (ws.py)  │
 │ msj_client/storage.py │                 │ Services / models        │
 └──────────┬────────────┘                 └───────────┬──────────────┘
            │                                          │
            ▼                                          ▼
   shared/msj_crypto (X3DH + Double Ratchet)     PostgreSQL (ciphertext only)
   encrypted-at-rest local state
```

## Trust boundary

The **server is untrusted for confidentiality**. It authenticates users, stores
public key bundles, and relays/stores ciphertext. It never receives plaintext
message content or private keys. All encryption and decryption happen on the
client, inside `shared/msj_crypto`.

## Shared E2EE core (`shared/msj_crypto`)

- `primitives.py` — concrete X25519 DH ratchet, HKDF-SHA256 KDF and AES-256-GCM
  AEAD plugged into `doubleratchet`, plus the concrete `MSJDoubleRatchet`.
- `x3dh_state.py` — X3DH state (`X3DHState`) with the two hooks the `x3dh`
  library requires (`_encode_public_key`, `_publish_bundle`).
- `session.py` — `SessionManager`: X3DH key agreement feeding the Double Ratchet;
  `Session`: per-peer ratchet with serialisation.
- `envelope.py` — the wire format (`Envelope`, `X3DHHeaderWire`) and bundle
  (de)serialisation helpers.
- `constants.py` — protocol constants (versioned).

The same core is used by the Android client (production) and by the backend
integration tests (to prove server blindness).

## Message flow (first message)

1. Sender fetches recipient bundle: `GET /api/v1/keys/bundle/{username}` —
   the server consumes one one-time pre-key.
2. `SessionManager.encrypt` runs X3DH (active) → shared secret; then
   `MSJDoubleRatchet.encrypt_initial_message` produces the first envelope
   (which carries the X3DH header).
3. Sender posts the envelope: `POST /api/v1/messages` (or over the WebSocket).
4. Server stores the opaque envelope and, if the recipient is online, pushes it
   over the WebSocket; otherwise it is queued for offline delivery.
5. Recipient completes X3DH (passive) from the header and decrypts.

Subsequent messages carry only the Double Ratchet header (no X3DH header).

## Data model

`users`, `identity_bundles` (public keys), `pre_keys` (public, one-time),
`devices`, `refresh_tokens` (hashed), `messages` (ciphertext), `audit_log`.

## Deferred: encrypted attachments (design)

Not implemented, kept off so no plaintext can leak. Intended design:

1. Sender generates a fresh random 256-bit content key and encrypts the file
   with AES-256-GCM.
2. Upload **only ciphertext** (`POST /attachments`), receiving an opaque id.
3. Send a normal E2EE message whose plaintext is the content key + file metadata
   + attachment id.
4. Recipient downloads the ciphertext and decrypts locally with the key.
5. No plaintext thumbnail is ever generated server-side; previews are rendered
   client-side after decryption. Enforce size/type limits server-side and do not
   trust client MIME types.

## Deferred: groups

Group E2EE needs a sender-key / group-ratchet scheme with correct membership
change handling (e.g. a Megolm-style design). Not implemented.
