"""Security-focused negative tests: malformed input, abuse and limits."""

from __future__ import annotations

from .conftest import PASSWORD, publish_bundle, register_account


async def test_invalid_registration_payloads(client):
    assert (await client.post("/api/v1/auth/register", json={})).status_code == 422
    assert (
        await client.post("/api/v1/auth/register", json={"username": "bad name", "password": PASSWORD})
    ).status_code == 422
    assert (
        await client.post("/api/v1/auth/register", json={"username": "ok_name", "password": "short"})
    ).status_code == 422


async def test_envelope_missing_fields_rejected(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    r = await client.post(
        "/api/v1/messages",
        json={"client_msg_id": "x", "recipient": "bob", "envelope": {"foo": "bar"}},
        headers=alice.headers,
    )
    assert r.status_code == 422


async def test_oversized_envelope_rejected(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    big = {"ratchet_pub": "A", "pn": 0, "n": 0, "ciphertext": "A" * 70000}
    r = await client.post(
        "/api/v1/messages",
        json={"client_msg_id": "x", "recipient": "bob", "envelope": big},
        headers=alice.headers,
    )
    assert r.status_code == 413


async def test_rate_limit_on_registration(client):
    # MSJ_RATE_LIMIT_AUTH_PER_MINUTE is set to 5 for tests.
    statuses = []
    for i in range(7):
        r = await client.post(
            "/api/v1/auth/register",
            json={"username": f"user{i}", "password": PASSWORD, "device_name": "d"},
        )
        statuses.append(r.status_code)
    assert 429 in statuses


async def test_invalid_history_cursor(client):
    alice = await register_account(client, "alice")
    await register_account(client, "bob")
    r = await client.get("/api/v1/messages?peer=bob&cursor=not-a-date", headers=alice.headers)
    assert r.status_code == 422


async def test_invalid_receipt_status(client):
    alice = await register_account(client, "alice")
    r = await client.post("/api/v1/messages/does-not-exist/receipt", json={"status": "explode"}, headers=alice.headers)
    assert r.status_code == 422
