"""Integration test driving the real client stack against the live backend.

Exercises ApiClient, MessengerCrypto and the encrypted FileSecureStore together,
proving the desktop-testable client code paths work end to end.
"""

from __future__ import annotations

import httpx
from app.main import app
from msj_client.api import ApiClient
from msj_client.config import ClientConfig
from msj_client.crypto_adapter import MessengerCrypto
from msj_client.storage import FileSecureStore
from msj_crypto import Envelope


def _client() -> ApiClient:
    cfg = ClientConfig(base_url="http://test")
    return ApiClient(cfg, transport=httpx.ASGITransport(app=app))


async def test_two_clients_exchange_encrypted_messages(tmp_path):
    alice_api, bob_api = _client(), _client()
    await alice_api.register("alice", "supersecret123", device_name="a-phone")
    await bob_api.register("bob", "supersecret123", device_name="b-phone")

    alice = MessengerCrypto(FileSecureStore(tmp_path / "alice.json", "alice-passphrase"), "alice")
    bob = MessengerCrypto(FileSecureStore(tmp_path / "bob.json", "bob-passphrase"), "bob")
    assert alice.load_or_create() is True
    assert bob.load_or_create() is True

    await alice_api.publish_bundle(alice.bundle_wire())
    await bob_api.publish_bundle(bob.bundle_wire())

    # Alice starts a conversation with Bob.
    bob_bundle = await alice_api.fetch_bundle("bob")
    env = await alice.encrypt("bob", b"hello from alice", peer_bundle_response=bob_bundle)
    ack = await alice_api.send_message("c1", "bob", env.to_dict())
    assert ack["status"] in {"stored", "delivered"}

    # Bob pulls history and decrypts.
    page = await bob_api.history("alice")
    assert len(page["messages"]) == 1
    stored = page["messages"][0]["envelope"]
    assert await bob.decrypt("alice", Envelope.from_dict(stored)) == b"hello from alice"

    # Bob replies; Alice decrypts.
    reply = await bob.encrypt("alice", b"hello from bob")
    await bob_api.send_message("r1", "alice", reply.to_dict())
    page = await alice_api.history("bob")
    stored = page["messages"][0]["envelope"]
    assert await alice.decrypt("bob", Envelope.from_dict(stored)) == b"hello from bob"

    # Safety numbers agree.
    alice_ik = alice.manager.identity_public_key()
    bob_ik = bob.manager.identity_public_key()
    assert alice.safety_number("bob", bob_ik) == bob.safety_number("alice", alice_ik)


async def test_session_state_survives_restart(tmp_path):
    alice_api, bob_api = _client(), _client()
    await alice_api.register("alice", "supersecret123")
    await bob_api.register("bob", "supersecret123")

    alice_path = tmp_path / "alice.json"
    alice = MessengerCrypto(FileSecureStore(alice_path, "pw"), "alice")
    alice.load_or_create()
    bob = MessengerCrypto(FileSecureStore(tmp_path / "bob.json", "pw"), "bob")
    bob.load_or_create()
    await alice_api.publish_bundle(alice.bundle_wire())
    await bob_api.publish_bundle(bob.bundle_wire())

    bundle = await alice_api.fetch_bundle("bob")
    env1 = await alice.encrypt("bob", b"before restart", peer_bundle_response=bundle)
    await alice_api.send_message("c1", "bob", env1.to_dict())
    await bob.decrypt("alice", Envelope.from_dict((await bob_api.history("alice"))["messages"][0]["envelope"]))

    # "Restart" Alice: rebuild from encrypted storage with the same passphrase.
    alice2 = MessengerCrypto(FileSecureStore(alice_path, "pw"), "alice")
    assert alice2.load_or_create() is False  # existing identity loaded
    assert alice2.manager.identity_public_key() == alice.manager.identity_public_key()

    env2 = await alice2.encrypt("bob", b"after restart")  # session restored, no bundle needed
    await alice_api.send_message("c2", "bob", env2.to_dict())
    msgs = (await bob_api.history("alice"))["messages"]
    # Newest first.
    assert await bob.decrypt("alice", Envelope.from_dict(msgs[0]["envelope"])) == b"after restart"
