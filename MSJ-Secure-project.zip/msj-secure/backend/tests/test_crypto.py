"""Unit tests for the shared E2EE core (X3DH + Double Ratchet)."""

from __future__ import annotations

import asyncio

import pytest
from doubleratchet import (
    AuthenticationFailedException,
    DecryptionFailedException,
    DuplicateMessageException,
)
from msj_crypto import Envelope, SessionManager
from msj_crypto.session import CryptoError
from x3dh import KeyAgreementException

# Exceptions that legitimately signal a rejected message: failed authentication,
# a key-agreement failure (e.g. a consumed one-time pre key) or our own session
# errors. Anything else should propagate and fail the test.
REJECTION_ERRORS = (
    AuthenticationFailedException,
    DecryptionFailedException,
    KeyAgreementException,
    CryptoError,
)


def test_round_trip_and_reply():
    async def run():
        alice, bob = SessionManager("alice"), SessionManager("bob")
        first = await alice.encrypt("bob", b"hello", peer_bundle=bob.bundle)
        assert first.x3dh is not None  # first message carries the X3DH header
        assert await bob.decrypt("alice", first) == b"hello"

        second = await alice.encrypt("bob", b"world")
        assert second.x3dh is None
        assert await bob.decrypt("alice", second) == b"world"

        reply = await bob.encrypt("alice", b"hi back")
        assert await alice.decrypt("bob", reply) == b"hi back"

    asyncio.run(run())


def test_envelope_serialisation_round_trip():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        env = await a.encrypt("b", b"payload", peer_bundle=b.bundle)
        clone = Envelope.from_json(env.to_json())
        assert clone.to_dict() == env.to_dict()
        assert await b.decrypt("a", clone) == b"payload"

    asyncio.run(run())


def test_out_of_order_delivery():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        m0 = await a.encrypt("b", b"m0", peer_bundle=b.bundle)
        assert await b.decrypt("a", m0) == b"m0"
        m1 = await a.encrypt("b", b"m1")
        m2 = await a.encrypt("b", b"m2")
        # Deliver out of order.
        assert await b.decrypt("a", m2) == b"m2"
        assert await b.decrypt("a", m1) == b"m1"

    asyncio.run(run())


def test_duplicate_followup_rejected():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        init = await a.encrypt("b", b"init", peer_bundle=b.bundle)
        assert await b.decrypt("a", init) == b"init"
        f = await a.encrypt("b", b"follow")
        assert await b.decrypt("a", f) == b"follow"
        with pytest.raises(DuplicateMessageException):
            await b.decrypt("a", f)

    asyncio.run(run())


def test_initial_message_replay_rejected():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        init = await a.encrypt("b", b"once", peer_bundle=b.bundle)
        assert await b.decrypt("a", init) == b"once"
        # Replaying the initial message must fail (one-time pre key consumed).
        with pytest.raises(REJECTION_ERRORS):
            await b.decrypt("a", init)

    asyncio.run(run())


def test_wrong_recipient_cannot_decrypt():
    async def run():
        a, b, c = SessionManager("a"), SessionManager("b"), SessionManager("c")
        env = await a.encrypt("b", b"top secret", peer_bundle=b.bundle)
        with pytest.raises(REJECTION_ERRORS):
            await c.decrypt("a", env)

    asyncio.run(run())


def test_tampered_ciphertext_rejected():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        init = await a.encrypt("b", b"authentic", peer_bundle=b.bundle)
        assert await b.decrypt("a", init) == b"authentic"
        env = await a.encrypt("b", b"tamper me")
        # Flip a byte in the ciphertext.
        tampered = bytearray(env.ciphertext)
        tampered[0] ^= 0x01
        env.ciphertext = bytes(tampered)
        with pytest.raises(REJECTION_ERRORS):
            await b.decrypt("a", env)

    asyncio.run(run())


def test_safety_number_symmetry():
    a, b = SessionManager("a"), SessionManager("b")
    assert a.safety_number("b", b.identity_public_key()) == b.safety_number("a", a.identity_public_key())
    assert len(a.safety_number("b", b.identity_public_key())) == 60


def test_session_export_and_restore():
    async def run():
        a, b = SessionManager("a"), SessionManager("b")
        init = await a.encrypt("b", b"one", peer_bundle=b.bundle)
        assert await b.decrypt("a", init) == b"one"

        # Persist and restore alice's sessions, then continue the conversation.
        blob = a.export_sessions()
        restored = SessionManager("a")
        restored.state = a.state  # reuse the same X3DH state for continuity
        restored.load_sessions(blob)

        cont = await restored.encrypt("b", b"two")
        assert await b.decrypt("a", cont) == b"two"

    asyncio.run(run())


def test_bundle_wire_round_trip():
    from msj_crypto import bundle_from_wire, bundle_to_wire

    s = SessionManager("x")
    wire = bundle_to_wire(s.bundle)
    back = bundle_from_wire(wire)
    assert back.identity_key == s.bundle.identity_key
    assert back.signed_pre_key == s.bundle.signed_pre_key
    assert back.pre_keys == s.bundle.pre_keys
