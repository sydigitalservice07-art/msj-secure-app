"""Message relay, history pagination, receipts and idempotency."""

from __future__ import annotations

from msj_crypto import Envelope

from .conftest import fetch_bundle, publish_bundle, register_account


async def _send(client, sender, recipient, text, client_msg_id):
    bundle = await fetch_bundle(client, sender, recipient.username)
    env = await sender.manager.encrypt(recipient.username, text, peer_bundle=bundle)
    return await client.post(
        "/api/v1/messages",
        json={"client_msg_id": client_msg_id, "recipient": recipient.username, "envelope": env.to_dict()},
        headers=sender.headers,
    )


async def test_send_store_and_history(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)

    r = await _send(client, alice, bob, b"hello bob", "c1")
    assert r.status_code == 201
    assert r.json()["status"] == "stored"  # bob is offline

    history = await client.get("/api/v1/messages?peer=alice", headers=bob.headers)
    assert history.status_code == 200
    msgs = history.json()["messages"]
    assert len(msgs) == 1
    env = msgs[0]["envelope"]
    plaintext = await bob.manager.decrypt("alice", Envelope.from_dict(env))
    assert plaintext == b"hello bob"


async def test_duplicate_client_msg_id_is_idempotent(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    first = await _send(client, alice, bob, b"once", "same-id")
    second = await _send(client, alice, bob, b"once", "same-id")
    assert first.json()["id"] == second.json()["id"]


async def test_history_pagination(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    for i in range(5):
        assert (await _send(client, alice, bob, f"m{i}".encode(), f"c{i}")).status_code == 201
    page1 = await client.get("/api/v1/messages?peer=alice&limit=2", headers=bob.headers)
    body = page1.json()
    assert len(body["messages"]) == 2
    assert body["next_cursor"] is not None
    page2 = await client.get(f"/api/v1/messages?peer=alice&limit=2&cursor={body['next_cursor']}", headers=bob.headers)
    ids1 = {m["id"] for m in body["messages"]}
    ids2 = {m["id"] for m in page2.json()["messages"]}
    assert ids1.isdisjoint(ids2)


async def test_receipt_updates_status(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    sent = await _send(client, alice, bob, b"ack me", "c1")
    mid = sent.json()["id"]
    assert (
        await client.post(f"/api/v1/messages/{mid}/receipt", json={"status": "read"}, headers=bob.headers)
    ).status_code == 204
    history = await client.get("/api/v1/messages?peer=bob", headers=alice.headers)
    msg = history.json()["messages"][0]
    assert msg["read_at"] is not None


async def test_send_to_unknown_recipient(client):
    alice = await register_account(client, "alice")
    await publish_bundle(client, alice)
    r = await client.post(
        "/api/v1/messages",
        json={
            "client_msg_id": "x",
            "recipient": "ghost",
            "envelope": {"ratchet_pub": "a", "pn": 0, "n": 0, "ciphertext": "b"},
        },
        headers=alice.headers,
    )
    assert r.status_code == 404
