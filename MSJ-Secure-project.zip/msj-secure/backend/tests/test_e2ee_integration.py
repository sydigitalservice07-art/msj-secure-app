"""End-to-end E2EE acceptance test.

Two clients exchange an encrypted message through the real backend, and we then
inspect the database directly to prove the server only ever holds ciphertext and
public key material.
"""

from __future__ import annotations

import base64

from app.database import SessionLocal
from app.models import IdentityBundle, Message, PreKey
from msj_crypto import Envelope
from sqlalchemy import select

from .conftest import fetch_bundle, publish_bundle, register_account


def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode()


async def test_end_to_end_encryption_and_server_blindness(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)

    secret = b"the eagle lands at dawn"
    bob_bundle = await fetch_bundle(client, alice, "bob")
    envelope = await alice.manager.encrypt("bob", secret, peer_bundle=bob_bundle)

    sent = await client.post(
        "/api/v1/messages",
        json={"client_msg_id": "s1", "recipient": "bob", "envelope": envelope.to_dict()},
        headers=alice.headers,
    )
    assert sent.status_code == 201

    # Bob retrieves the ciphertext and decrypts it locally.
    history = await client.get("/api/v1/messages?peer=alice", headers=bob.headers)
    stored = history.json()["messages"][0]["envelope"]
    assert await bob.manager.decrypt("alice", Envelope.from_dict(stored)) == secret

    # A third party cannot decrypt the relayed ciphertext.
    carol = await register_account(client, "carol")
    try:
        await carol.manager.decrypt("alice", Envelope.from_dict(stored))
        decrypted_by_carol = True
    except Exception:
        decrypted_by_carol = False
    assert not decrypted_by_carol

    # ---- Server blindness: inspect the database directly ------------------
    async with SessionLocal() as session:
        messages = (await session.execute(select(Message))).scalars().all()
        assert len(messages) == 1
        blob = messages[0].envelope
        assert secret.decode() not in blob  # no plaintext
        assert "priv" not in blob.lower()
        assert "seed" not in blob.lower()

        bundles = (await session.execute(select(IdentityBundle))).scalars().all()
        by_user = {b.user_id: b for b in bundles}
        assert set(by_user) == {alice.tokens["user_id"], bob.tokens["user_id"]}
        # The stored identity key is Alice's *public* identity key, not a private one.
        assert by_user[alice.tokens["user_id"]].identity_key == _b64(alice.manager.identity_public_key())

        pre_keys = (await session.execute(select(PreKey))).scalars().all()
        for pk in pre_keys:
            assert secret.decode() not in pk.public_key


async def test_offline_ciphertext_delivery_after_reconnect(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)

    bundle = await fetch_bundle(client, alice, "bob")
    env = await alice.manager.encrypt("bob", b"while you were out", peer_bundle=bundle)
    sent = await client.post(
        "/api/v1/messages",
        json={"client_msg_id": "off1", "recipient": "bob", "envelope": env.to_dict()},
        headers=alice.headers,
    )
    # Bob was offline, so the message is stored, not delivered.
    assert sent.json()["status"] == "stored"

    # When Bob next fetches history, the ciphertext is there and decrypts.
    history = await client.get("/api/v1/messages?peer=alice", headers=bob.headers)
    stored = history.json()["messages"][0]["envelope"]
    assert await bob.manager.decrypt("alice", Envelope.from_dict(stored)) == b"while you were out"
