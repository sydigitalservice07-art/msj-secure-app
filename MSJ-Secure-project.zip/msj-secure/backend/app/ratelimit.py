"""A small in-process fixed-window rate limiter.

Suitable for a single backend instance; for a multi-instance deployment swap the
store for Redis (see SECURITY.md). Raises HTTP 429 when a limit is exceeded.
"""

from __future__ import annotations

import asyncio
import time
from collections import defaultdict
from typing import Dict, Tuple

from fastapi import HTTPException, status


class RateLimiter:
    def __init__(self) -> None:
        self._hits: Dict[str, Tuple[int, float]] = defaultdict(lambda: (0, 0.0))
        self._lock = asyncio.Lock()

    async def check(self, key: str, limit: int, window_seconds: int = 60) -> None:
        now = time.monotonic()
        async with self._lock:
            count, window_start = self._hits[key]
            if now - window_start >= window_seconds:
                count, window_start = 0, now
            count += 1
            self._hits[key] = (count, window_start)
            if count > limit:
                retry_after = int(window_seconds - (now - window_start)) + 1
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail="rate limit exceeded",
                    headers={"Retry-After": str(max(retry_after, 1))},
                )

    async def reset(self) -> None:
        async with self._lock:
            self._hits.clear()


limiter = RateLimiter()
