"""Message relay: store-and-forward of ciphertext envelopes.

The server treats the envelope as an opaque blob. It cannot decrypt it and does
not attempt to.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, Query, Request, status
from sqlalchemy import and_, or_, select

from ..deps import CurrentUser, DbSession, SettingsDep
from ..models import Message
from ..ratelimit import limiter
from ..schemas import MessageAck, MessagePage, ReceiptRequest, SendMessageRequest, StoredMessage
from ..services import get_user_by_username, send_message_core
from ..ws import manager

router = APIRouter(prefix="/api/v1/messages", tags=["messages"])


def _to_stored(m: Message, usernames: dict[str, str]) -> StoredMessage:
    return StoredMessage(
        id=m.id,
        sender=usernames.get(m.sender_id, m.sender_id),
        recipient=usernames.get(m.recipient_id, m.recipient_id),
        envelope=json.loads(m.envelope),
        created_at=m.created_at,
        delivered_at=m.delivered_at,
        read_at=m.read_at,
    )


@router.post("", response_model=MessageAck, status_code=status.HTTP_201_CREATED)
async def send_message(
    body: SendMessageRequest,
    request: Request,
    user: CurrentUser,
    session: DbSession,
    settings: SettingsDep,
) -> MessageAck:
    await limiter.check(f"send:{user.id}", settings.rate_limit_messages_per_minute)
    result = await send_message_core(
        session, settings, manager, user, body.recipient, body.client_msg_id, body.envelope
    )
    return MessageAck(**result)


@router.get("", response_model=MessagePage)
async def history(
    user: CurrentUser,
    session: DbSession,
    peer: str = Query(min_length=1, max_length=32),
    limit: int = Query(default=50, ge=1, le=200),
    cursor: str | None = Query(default=None),
) -> MessagePage:
    other = await get_user_by_username(session, peer)
    if other is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user not found")

    stmt = select(Message).where(
        or_(
            and_(Message.sender_id == user.id, Message.recipient_id == other.id),
            and_(Message.sender_id == other.id, Message.recipient_id == user.id),
        )
    )
    if cursor:
        try:
            cursor_dt = datetime.fromisoformat(cursor)
        except ValueError as exc:
            raise HTTPException(status_code=422, detail="invalid cursor") from exc
        stmt = stmt.where(Message.created_at < cursor_dt)
    stmt = stmt.order_by(Message.created_at.desc()).limit(limit + 1)

    rows = (await session.execute(stmt)).scalars().all()
    has_more = len(rows) > limit
    rows = rows[:limit]
    usernames = {user.id: user.username, other.id: other.username}
    next_cursor = rows[-1].created_at.isoformat() if (has_more and rows) else None
    return MessagePage(messages=[_to_stored(m, usernames) for m in rows], next_cursor=next_cursor)


@router.post("/{message_id}/receipt", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def receipt(
    message_id: str,
    body: ReceiptRequest,
    user: CurrentUser,
    session: DbSession,
) -> None:
    message = await session.get(Message, message_id)
    if message is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="message not found")
    # Only the recipient may acknowledge delivery/read.
    if message.recipient_id != user.id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="not your message")

    now = datetime.now(timezone.utc)
    if message.delivered_at is None:
        message.delivered_at = now
    if body.status == "read":
        message.read_at = now

    await session.commit()
    await manager.send_to_user(
        message.sender_id,
        {
            "type": "receipt",
            "id": message.id,
            "status": body.status,
            "at": now.isoformat(),
        },
    )


@router.delete("/{message_id}", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def delete_message(message_id: str, user: CurrentUser, session: DbSession) -> None:
    message = await session.get(Message, message_id)
    if message is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="message not found")
    if user.id not in (message.sender_id, message.recipient_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="not your message")
    await session.delete(message)
    await session.commit()
