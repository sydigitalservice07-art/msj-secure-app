"""Authentication: registration, login, refresh, logout, account management."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select, update

from ..deps import CurrentUser, DbSession, SettingsDep, get_current_device
from ..models import Device, RefreshToken, User
from ..ratelimit import limiter
from ..schemas import (
    AccountDeleteRequest,
    ChangePasswordRequest,
    LoginRequest,
    RefreshRequest,
    RegisterRequest,
    TokenResponse,
)
from ..security import create_access_token, hash_password, needs_rehash, verify_password
from ..services import audit, create_device_with_tokens, get_user_by_username, rotate_refresh_token

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _client_key(request: Request) -> str:
    return request.client.host if request.client else "unknown"


def _token_response(settings, user, device, raw_refresh) -> TokenResponse:
    return TokenResponse(
        access_token=create_access_token(settings, user.id, device.id),
        refresh_token=raw_refresh,
        expires_in=settings.access_token_ttl_minutes * 60,
        user_id=user.id,
        device_id=device.id,
    )


@router.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(body: RegisterRequest, request: Request, session: DbSession, settings: SettingsDep) -> TokenResponse:
    await limiter.check(f"register:{_client_key(request)}", settings.rate_limit_auth_per_minute)
    if await get_user_by_username(session, body.username) is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="username already taken")

    user = User(
        username=body.username,
        username_lower=body.username.lower(),
        password_hash=hash_password(body.password),
    )
    session.add(user)
    await session.flush()
    device, raw_refresh = await create_device_with_tokens(session, settings, user, body.device_name, body.platform)
    await audit(session, "register", user.id)
    await session.commit()
    return _token_response(settings, user, device, raw_refresh)


@router.post("/login", response_model=TokenResponse)
async def login(body: LoginRequest, request: Request, session: DbSession, settings: SettingsDep) -> TokenResponse:
    await limiter.check(f"login:{_client_key(request)}", settings.rate_limit_auth_per_minute)
    user = await get_user_by_username(session, body.username)
    if user is None or not verify_password(body.password, user.password_hash):
        await audit(session, "login_failed", user.id if user else None)
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid credentials")
    if not user.is_active:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="account disabled")
    if needs_rehash(user.password_hash):
        user.password_hash = hash_password(body.password)
    device, raw_refresh = await create_device_with_tokens(session, settings, user, body.device_name, body.platform)
    await audit(session, "login", user.id)
    await session.commit()
    return _token_response(settings, user, device, raw_refresh)


@router.post("/refresh", response_model=TokenResponse)
async def refresh(body: RefreshRequest, request: Request, session: DbSession, settings: SettingsDep) -> TokenResponse:
    await limiter.check(f"refresh:{_client_key(request)}", settings.rate_limit_auth_per_minute)
    user, device, new_raw = await rotate_refresh_token(session, settings, body.refresh_token)
    await session.commit()
    return _token_response(settings, user, device, new_raw)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def logout(user: CurrentUser, session: DbSession, device: Device = Depends(get_current_device)) -> None:
    """End the current device session: revoke its refresh tokens and the device."""
    await session.execute(
        update(RefreshToken)
        .where(RefreshToken.device_id == device.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=_now())
    )
    device.revoked_at = _now()
    await audit(session, "logout", user.id)
    await session.commit()


@router.get("/me")
async def me(user: CurrentUser, device: Device = Depends(get_current_device)) -> dict:
    return {
        "id": user.id,
        "username": user.username,
        "device": {"id": device.id, "name": device.name, "platform": device.platform},
    }


@router.post("/change-password", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def change_password(body: ChangePasswordRequest, user: CurrentUser, session: DbSession) -> None:
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="current password incorrect")
    user.password_hash = hash_password(body.new_password)
    # Revoke all refresh tokens on password change.
    await session.execute(
        update(RefreshToken)
        .where(RefreshToken.user_id == user.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=_now())
    )
    await audit(session, "password_changed", user.id)
    await session.commit()


@router.post("/delete-account", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def delete_account(body: AccountDeleteRequest, user: CurrentUser, session: DbSession) -> None:
    if not verify_password(body.password, user.password_hash):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="password incorrect")
    # Cascades remove devices, tokens, bundles, pre keys and messages.
    await session.delete(user)
    await audit(session, "account_deleted", None)
    await session.commit()


@router.get("/export")
async def export_account(user: CurrentUser, session: DbSession) -> dict:
    """Data export: account metadata and ciphertext message records."""
    from ..models import Message

    rows = (
        (
            await session.execute(
                select(Message).where((Message.sender_id == user.id) | (Message.recipient_id == user.id))
            )
        )
        .scalars()
        .all()
    )
    return {
        "account": {"id": user.id, "username": user.username, "created_at": user.created_at.isoformat()},
        "messages": [
            {
                "id": m.id,
                "sender_id": m.sender_id,
                "recipient_id": m.recipient_id,
                "envelope": m.envelope,
                "created_at": m.created_at.isoformat(),
            }
            for m in rows
        ],
        "note": "Message bodies are end-to-end encrypted; this export contains ciphertext only.",
    }
