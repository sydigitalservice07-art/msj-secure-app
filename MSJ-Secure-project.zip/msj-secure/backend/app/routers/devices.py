"""Device / session management."""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import select, update

from ..deps import CurrentUser, DbSession
from ..models import Device, RefreshToken
from ..schemas import DevicePublic
from ..services import audit

router = APIRouter(prefix="/api/v1/devices", tags=["devices"])


@router.get("", response_model=list[DevicePublic])
async def list_devices(user: CurrentUser, session: DbSession) -> list[DevicePublic]:
    rows = (
        (await session.execute(select(Device).where(Device.user_id == user.id).order_by(Device.created_at.desc())))
        .scalars()
        .all()
    )
    return [
        DevicePublic(
            id=d.id,
            name=d.name,
            platform=d.platform,
            created_at=d.created_at,
            last_seen_at=d.last_seen_at,
            revoked=d.revoked_at is not None,
        )
        for d in rows
    ]


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def revoke_device(device_id: str, user: CurrentUser, session: DbSession) -> None:
    device = await session.get(Device, device_id)
    if device is None or device.user_id != user.id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="device not found")
    device.revoked_at = datetime.now(timezone.utc)
    await session.execute(
        update(RefreshToken)
        .where(RefreshToken.device_id == device.id, RefreshToken.revoked_at.is_(None))
        .values(revoked_at=datetime.now(timezone.utc))
    )
    await audit(session, "device_revoked", user.id, detail=device.id)
    await session.commit()
