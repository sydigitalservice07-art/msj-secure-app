"""Authenticated WebSocket relay for real-time ciphertext delivery.

The socket carries only ciphertext envelopes, receipts and control frames. On
connect, any messages queued while the recipient was offline are flushed.
"""

from __future__ import annotations

import json
import logging
from typing import Dict, Set

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect, status
from sqlalchemy import select

from .config import get_settings
from .database import SessionLocal
from .models import Device, Message, User
from .security import TokenError, decode_access_token
from .services import send_message_core

logger = logging.getLogger("msj.ws")

router = APIRouter()


class ConnectionManager:
    """Tracks live sockets per user id."""

    def __init__(self) -> None:
        self._conns: Dict[str, Set[WebSocket]] = {}

    async def connect(self, user_id: str, ws: WebSocket) -> None:
        await ws.accept()
        self._conns.setdefault(user_id, set()).add(ws)

    def disconnect(self, user_id: str, ws: WebSocket) -> None:
        conns = self._conns.get(user_id)
        if conns and ws in conns:
            conns.discard(ws)
        if conns is not None and not conns:
            self._conns.pop(user_id, None)

    def is_online(self, user_id: str) -> bool:
        return bool(self._conns.get(user_id))

    async def send_to_user(self, user_id: str, payload: dict) -> bool:
        conns = list(self._conns.get(user_id, ()))
        if not conns:
            return False
        text = json.dumps(payload, separators=(",", ":"))
        delivered = False
        for ws in conns:
            try:
                await ws.send_text(text)
                delivered = True
            except Exception:
                self.disconnect(user_id, ws)
        return delivered


manager = ConnectionManager()


async def _authenticate(token: str):
    settings = get_settings()
    try:
        payload = decode_access_token(settings, token)
    except TokenError:
        return None
    async with SessionLocal() as session:
        user = await session.get(User, payload["sub"])
        device = await session.get(Device, payload.get("did"))
        if (
            user is None
            or not user.is_active
            or device is None
            or device.revoked_at is not None
            or device.user_id != user.id
        ):
            return None
        return user.id


async def _flush_offline(user_id: str) -> None:
    """Deliver messages that arrived while the user was offline."""
    async with SessionLocal() as session:
        rows = (
            (
                await session.execute(
                    select(Message)
                    .where(Message.recipient_id == user_id, Message.delivered_at.is_(None))
                    .order_by(Message.created_at.asc())
                    .limit(500)
                )
            )
            .scalars()
            .all()
        )
        if not rows:
            return
        # Resolve sender usernames in one pass.
        sender_ids = {m.sender_id for m in rows}
        senders = {
            u.id: u.username
            for u in (await session.execute(select(User).where(User.id.in_(sender_ids)))).scalars().all()
        }
        from datetime import datetime, timezone

        now = datetime.now(timezone.utc)
        for m in rows:
            await manager.send_to_user(
                user_id,
                {
                    "type": "message",
                    "id": m.id,
                    "client_msg_id": m.client_msg_id,
                    "sender": senders.get(m.sender_id, m.sender_id),
                    "envelope": json.loads(m.envelope),
                    "created_at": m.created_at.isoformat(),
                    "queued": True,
                },
            )
            m.delivered_at = now
        await session.commit()


@router.websocket("/api/v1/ws")
async def websocket_endpoint(ws: WebSocket, token: str = Query(default="")) -> None:
    user_id = await _authenticate(token)
    if user_id is None:
        await ws.close(code=status.WS_1008_POLICY_VIOLATION)
        return

    await manager.connect(user_id, ws)
    try:
        await _flush_offline(user_id)
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await ws.send_text(json.dumps({"type": "error", "detail": "invalid json"}))
                continue

            mtype = msg.get("type")
            if mtype == "ping":
                await ws.send_text(json.dumps({"type": "pong"}))
            elif mtype == "send":
                await _handle_send(ws, user_id, msg)
            elif mtype == "receipt":
                await _handle_receipt(ws, user_id, msg)
            else:
                await ws.send_text(json.dumps({"type": "error", "detail": "unknown type"}))
    except WebSocketDisconnect:
        pass
    finally:
        manager.disconnect(user_id, ws)


async def _handle_send(ws: WebSocket, user_id: str, msg: dict) -> None:
    async with SessionLocal() as session:
        user = await session.get(User, user_id)
        try:
            recipient = msg.get("recipient", "")
            result = await send_message_core(
                session,
                get_settings(),
                manager,
                user,
                recipient,
                str(msg.get("client_msg_id", "")),
                msg.get("envelope", {}),
            )
            await ws.send_text(json.dumps({"type": "ack", **result}))
        except Exception as exc:  # surface a clean error to the client
            await session.rollback()
            detail = getattr(exc, "detail", str(exc))
            await ws.send_text(json.dumps({"type": "error", "detail": detail}))


async def _handle_receipt(ws: WebSocket, user_id: str, msg: dict) -> None:
    from datetime import datetime, timezone

    async with SessionLocal() as session:
        message = await session.get(Message, str(msg.get("id", "")))
        if message is None or message.recipient_id != user_id:
            await ws.send_text(json.dumps({"type": "error", "detail": "invalid receipt"}))
            return
        now = datetime.now(timezone.utc)
        if message.delivered_at is None:
            message.delivered_at = now
        if msg.get("status") == "read":
            message.read_at = now
        await session.commit()
        await manager.send_to_user(
            message.sender_id,
            {"type": "receipt", "id": message.id, "status": msg.get("status"), "at": now.isoformat()},
        )
