"""Password hashing, JWT access tokens and refresh-token handling.

* Passwords: Argon2id via ``argon2-cffi`` (its default is Argon2id). Never
  stored or logged in plaintext.
* Access tokens: short-lived JWTs (HS256).
* Refresh tokens: 256-bit random values, stored only as SHA-256 hashes, rotated
  on every use.
"""

from __future__ import annotations

import hashlib
import secrets
from datetime import datetime, timedelta, timezone

import jwt
from argon2 import PasswordHasher
from argon2.exceptions import InvalidHashError, VerifyMismatchError

from .config import Settings

_hasher = PasswordHasher()  # Argon2id with library defaults


class TokenError(Exception):
    """Raised when a JWT is missing, malformed, expired or otherwise invalid."""


# ---- passwords -----------------------------------------------------------


def hash_password(password: str) -> str:
    return _hasher.hash(password)


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return _hasher.verify(password_hash, password)
    except (VerifyMismatchError, InvalidHashError, Exception):
        return False


def needs_rehash(password_hash: str) -> bool:
    try:
        return _hasher.check_needs_rehash(password_hash)
    except Exception:
        return False


# ---- access tokens -------------------------------------------------------


def create_access_token(settings: Settings, user_id: str, device_id: str) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": user_id,
        "did": device_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=settings.access_token_ttl_minutes)).timestamp()),
        "type": "access",
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)


def decode_access_token(settings: Settings, token: str) -> dict:
    try:
        payload: dict = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    except jwt.ExpiredSignatureError as exc:
        raise TokenError("token expired") from exc
    except jwt.PyJWTError as exc:
        raise TokenError("invalid token") from exc
    if payload.get("type") != "access":
        raise TokenError("wrong token type")
    return payload


# ---- refresh tokens ------------------------------------------------------


def generate_refresh_token() -> str:
    return secrets.token_urlsafe(32)


def hash_refresh_token(raw: str) -> str:
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
