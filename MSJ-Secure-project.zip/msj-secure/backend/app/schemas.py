"""Pydantic request/response schemas (validation at the API boundary)."""

from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field, field_validator

USERNAME_RE = r"^[a-zA-Z0-9_.]{3,32}$"


class RegisterRequest(BaseModel):
    username: str = Field(min_length=3, max_length=32, pattern=USERNAME_RE)
    password: str = Field(min_length=10, max_length=256)
    device_name: str = Field(default="device", max_length=64)
    platform: str = Field(default="unknown", max_length=32)


class LoginRequest(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=1, max_length=256)
    device_name: str = Field(default="device", max_length=64)
    platform: str = Field(default="unknown", max_length=32)


class RefreshRequest(BaseModel):
    refresh_token: str = Field(min_length=10, max_length=512)


class TokenResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user_id: str
    device_id: str


class UserPublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    username: str


class UserSearchResponse(BaseModel):
    results: List[UserPublic]
    next_offset: Optional[int] = None


class BundleUpload(BaseModel):
    identity_key: str = Field(min_length=8, max_length=128)
    signed_pre_key: str = Field(min_length=8, max_length=128)
    signed_pre_key_sig: str = Field(min_length=8, max_length=256)
    pre_keys: List[str] = Field(default_factory=list, max_length=200)

    @field_validator("pre_keys")
    @classmethod
    def _unique(cls, v: List[str]) -> List[str]:
        if len(set(v)) != len(v):
            raise ValueError("pre_keys must be unique")
        return v


class PreKeyRefill(BaseModel):
    pre_keys: List[str] = Field(min_length=1, max_length=200)

    @field_validator("pre_keys")
    @classmethod
    def _unique(cls, v: List[str]) -> List[str]:
        if len(set(v)) != len(v):
            raise ValueError("pre_keys must be unique")
        return v


class BundleResponse(BaseModel):
    username: str
    identity_key: str
    signed_pre_key: str
    signed_pre_key_sig: str
    pre_key: Optional[str] = None
    pre_key_count: int = 0


class SendMessageRequest(BaseModel):
    client_msg_id: str = Field(min_length=1, max_length=64)
    recipient: str = Field(min_length=3, max_length=32)
    envelope: dict  # opaque E2EE envelope; never interpreted by the server


class MessageAck(BaseModel):
    id: str
    client_msg_id: str
    status: str  # stored | delivered


class StoredMessage(BaseModel):
    id: str
    sender: str
    recipient: str
    envelope: dict
    created_at: datetime
    delivered_at: Optional[datetime] = None
    read_at: Optional[datetime] = None


class MessagePage(BaseModel):
    messages: List[StoredMessage]
    next_cursor: Optional[str] = None


class ReceiptRequest(BaseModel):
    status: str = Field(pattern="^(delivered|read)$")


class DevicePublic(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    name: str
    platform: str
    created_at: datetime
    last_seen_at: datetime
    revoked: bool = False


class ChangePasswordRequest(BaseModel):
    current_password: str = Field(min_length=1, max_length=256)
    new_password: str = Field(min_length=10, max_length=256)


class AccountDeleteRequest(BaseModel):
    password: str = Field(min_length=1, max_length=256)
