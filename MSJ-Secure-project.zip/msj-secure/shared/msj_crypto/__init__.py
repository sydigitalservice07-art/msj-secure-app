"""MSJ Secure shared end-to-end-encryption core.

This package wraps two maintained, pure-Python implementations of the Signal
protocol primitives:

* ``x3dh`` (X3DH asynchronous key agreement)
* ``doubleratchet`` (the Double Ratchet)

It only *composes* those vetted building blocks; it does not implement any
cryptographic primitive of its own. All primitives (X25519, HKDF-SHA256,
AES-256-GCM) come from the ``cryptography`` library.
"""

from .constants import (
    APP_INFO,
    DOS_PROTECTION_THRESHOLD,
    MAX_SKIPPED_MESSAGE_KEYS,
    MESSAGE_CHAIN_CONSTANT,
    PROTOCOL_VERSION,
)
from .envelope import (
    Envelope,
    X3DHHeaderWire,
    bundle_from_bundle_response,
    bundle_from_wire,
    bundle_to_wire,
)
from .primitives import AesGcm, HkdfSha256, MSJDoubleRatchet, X25519Ratchet
from .session import Session, SessionManager
from .x3dh_state import X3DHState

__all__ = [
    "APP_INFO",
    "MESSAGE_CHAIN_CONSTANT",
    "DOS_PROTECTION_THRESHOLD",
    "MAX_SKIPPED_MESSAGE_KEYS",
    "PROTOCOL_VERSION",
    "AesGcm",
    "HkdfSha256",
    "X25519Ratchet",
    "MSJDoubleRatchet",
    "X3DHState",
    "Envelope",
    "X3DHHeaderWire",
    "bundle_to_wire",
    "bundle_from_wire",
    "bundle_from_bundle_response",
    "Session",
    "SessionManager",
]
